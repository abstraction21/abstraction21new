import CTA from './CTA';
import Footer from './Footer';
import Header from './Header';
import Hero from './Hero';
import Posts from './Posts';

export { CTA, Footer, Header, Hero, Posts };
