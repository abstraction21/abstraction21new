# Headless WordPress Getting Started Example

## Setup

See the [setup steps](https://github.com/wpengine/headless-framework#quick-start).

## Run it

```bash
npm install
npm run dev
```

[http://localhost:3000]()
