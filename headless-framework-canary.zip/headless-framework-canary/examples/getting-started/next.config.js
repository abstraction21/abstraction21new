const withWPEHeadless = require('@wpengine/headless/nextConfig');

module.exports = withWPEHeadless();
