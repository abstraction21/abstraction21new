import { authorizeHandler } from '@wpengine/headless';

export default authorizeHandler;
