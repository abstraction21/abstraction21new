@wpengine/headless / [Exports](modules.md)

# WordPress Headless Framework

[![Version](https://img.shields.io/npm/v/@wpengine/headless.svg)](https://npmjs.org/package/@wpengine/headless)

NOTE: This project is in the early stages of development, but it does contain useful functionality for headless WordPress sites like authentication and post previews. Be sure to install the [WordPress plugin](https://github.com/wpengine/headless-framework) that enables the functionality in this package.

[Documentation](https://github.com/wpengine/headless-framework)
