module.exports = {
  arrowParens: 'always',
  jsxBracketSameLine: true,
  singleQuote: true,
  tabWidth: 2,
  semi: true,
  trailingComma: 'all',
  endOfLine: 'lf',
  useTabs: false,
};
