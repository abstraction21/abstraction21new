/* eslint-disable @typescript-eslint/triple-slash-reference */
/// <reference path="./src/types/next.d.ts" />
/// <reference path="./src/types/request.d.ts" />
/// <reference path="./src/types/wpgraphql.d.ts" />

export * from './dist/next';
