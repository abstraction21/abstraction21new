export const GENERAL_SETTINGS = `
  query GeneralSettings {
    generalSettings {
      title
      description
      url
    }
  }
`;
